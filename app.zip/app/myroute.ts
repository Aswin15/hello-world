// import { EmployeeComponent } from './employee/employee.component';
import { NavigationComponent } from './navigation/navigation.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import{ RouterModule,Routes } from '@angular/router';
import { ErrorComponent } from './error/error.component';
// import { CreateemployeeComponent } from "app/employee/createemployee/createemployee.component";
// import { EmployeedetailComponent } from "app/employee/employeedetail/employeedetail.component";
// import { SingleemployeeComponent } from './employee/singleemployee/singleemployee.component';

const myRoute:Routes=[
  {path:'',component:HomeComponent},
  {path:'home',component:HomeComponent},
  {path:'home/:id',component:HomeComponent},
  {path:'about',component:AboutComponent}, 
{path :'employee',loadChildren:'./employee/employeemodule/employee.module#EmployeeModule'},
  {path:'**',component:ErrorComponent}
]

export const Route=RouterModule.forRoot(myRoute);