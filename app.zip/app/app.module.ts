import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { NavigationComponent } from './navigation/navigation.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { RouterModule,Routes } from '@angular/router';
import { ErrorComponent } from './error/error.component';

import {Route} from './myroute';
import { employeeservice } from './shared/services/employeeservice';

@NgModule({
  declarations: [
    AppComponent,
    
    NavigationComponent,
    HomeComponent,
    AboutComponent,
    ErrorComponent,
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,Route
  ],
  providers: [employeeservice],
  bootstrap: [AppComponent]
})
export class AppModule { }
