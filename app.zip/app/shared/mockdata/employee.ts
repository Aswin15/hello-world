import { employee } from '../model/employee';

export let employeeList : employee[]=[
    {Empid:1,Empname:"Ronaldo",Empage:20},
    {Empid:5,Empname:"Messi",Empage:30},
    {Empid:7,Empname:"Pogba",Empage:25},
    {Empid:2,Empname:"Lukaku",Empage:15},
    {Empid:9,Empname:"Neymar",Empage:26}
];