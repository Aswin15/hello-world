import { Injectable }  from  '@angular/core';
import { employeeList }from '../mockdata/employee';
import { employee } from '../model/employee';
import { Http } from  '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()
export class employeeservice{

constructor(private http:Http)
{

}

getallemployees()
{
    return this.http.get('http://localhost:8081/employee').map(response=>response.json())
}

saveemployee(emp)
{
this.http.post('http://localhost:8081/employee',emp)
}
}


























