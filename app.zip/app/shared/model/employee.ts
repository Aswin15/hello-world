export class employee
{
    Empid : number;
    Empname :string;
    Empage : number;
}