import { Component, OnInit } from '@angular/core';
import { employeeservice } from "app/shared/services/employeeservice";
import { employee } from '../../shared/model/employee';

@Component({
  selector: 'app-createemployee',
  templateUrl: './createemployee.component.html',
  styleUrls: ['./createemployee.component.css']
})
export class CreateemployeeComponent implements OnInit {

  constructor(private empservice:employeeservice) { }

empno =10;
empname;
empage;

  ngOnInit() {
  }
  myemp:employee;
save()
{

this.myemp={Empid:this.empno,Empname:this.empname,Empage:this.empage};


  this.empservice.saveemployee(this.myemp);
}

}
