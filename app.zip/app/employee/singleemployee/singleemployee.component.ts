import { Component, OnInit } from '@angular/core';
import  { employeeservice } from '../../shared/services/employeeservice';
import { employee } from '../../shared/model/employee';
import { Router, ActivatedRoute} from '@angular/router';
@Component({
  selector: 'app-singleemployee',
  templateUrl: './singleemployee.component.html',
  styleUrls: ['./singleemployee.component.css']
})
export class SingleemployeeComponent implements OnInit {


myemploy:employee[]
extractedid:number
employeedetails:employee
  constructor(private empservice:employeeservice , private router:Router, private activatedroute:ActivatedRoute) { }

  ngOnInit() {
    
    this.empservice.getallemployees().subscribe(data=>this.myemploy=data);
    console.log(this.myemploy);
 this.extractedid= this.activatedroute.snapshot.params['id'];
//this.employeedetails= this.myemploy.find(x=>x.Empid==this.extractedid)

  }

}
