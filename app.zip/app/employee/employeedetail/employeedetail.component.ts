import { Component, OnInit } from '@angular/core';
import  { employeeservice } from '../../shared/services/employeeservice';
import { employee } from '../../shared/model/employee';
import { Router, ActivatedRoute} from '@angular/router';


@Component({
  selector: 'app-employeedetail',
  templateUrl: './employeedetail.component.html',
  styleUrls: ['./employeedetail.component.css']
})
export class EmployeedetailComponent implements OnInit {
  empid: any;
extractedid:number;
employeedetails:employee;
employeedetails1:employee;
empnumber : number;
  constructor(private empservice:employeeservice , private router:Router, private activatedroute:ActivatedRoute) {
  }
myemploy:employee[];


  ngOnInit() {
    this.empservice.getallemployees().subscribe(data=>this.myemploy=data);
  }

getdetails(empid)
{
 let path =['/employee/employeedetail',empid];
  this.router.navigate(path);

}

}
