import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeComponent } from "app/employee/employee.component";
import { CreateemployeeComponent } from "app/employee/createemployee/createemployee.component";
import { EmployeedetailComponent } from "app/employee/employeedetail/employeedetail.component";
import { SingleemployeeComponent } from "app/employee/singleemployee/singleemployee.component";
import { empRoute } from "app/employee/employeeroute";
import { employeeservice } from "app/shared/services/employeeservice";
import { HttpModule } from "@angular/http";
import { FormsModule } from "@angular/forms";
import { BrowserModule } from "@angular/platform-browser";

@NgModule({
  imports: [
    CommonModule,empRoute,
    FormsModule,
    HttpModule
  ],
  declarations: [EmployeeComponent,
  CreateemployeeComponent,
    EmployeedetailComponent,
    SingleemployeeComponent,  
  ],

  providers: [employeeservice],
})
export class EmployeeModule { }
