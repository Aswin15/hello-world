import { EmployeeComponent } from "app/employee/employee.component";
import { CreateemployeeComponent } from "app/employee/createemployee/createemployee.component";
import { EmployeedetailComponent } from "app/employee/employeedetail/employeedetail.component";
import { SingleemployeeComponent } from "app/employee/singleemployee/singleemployee.component";
import{ RouterModule,Routes } from '@angular/router';
const myempRoute: Routes = [
  {path:'',component:EmployeeComponent,

children :[{path:'createemployee',component: CreateemployeeComponent},
{path:'viewallemployee',component: EmployeedetailComponent},
{path:"employeedetail/:id",component: SingleemployeeComponent}]
}

]

export const empRoute=RouterModule.forChild(myempRoute);